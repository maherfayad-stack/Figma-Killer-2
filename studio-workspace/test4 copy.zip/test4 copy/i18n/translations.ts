/**
 * translations — every user-facing string in this app, in every language it
 * ships. Studio's Content panel reads and writes this file directly.
 *
 * Add a key to BOTH locales. A key missing from `ar` falls back to nothing,
 * not to English, so an untranslated string shows as blank in Arabic.
 */
export const translations = {
  en: {
    sheetHeader: {
      back: 'Back',
      close: 'Close'
    },
    cssProbe: {
      probe: 'probe',
      addYourTextHere: 'Add your text here.'
    },
    home: {
      home: 'Home',
      startEditingThisPageIn: 'Start editing this page in Studio.'
    },
    onboardingHero: {
      almosafer: 'Almosafer',
      _941Am: '9:41 AM',
      goodNewsAFewHotels: 'Good news! A few hotels you were interested in just had a 30% price drop'
    },
    onboarding: {
      completeYourSetupDonT: 'Complete your setup. Don’t miss out on:',
      uniqueRatesViaWhatsappEmail: 'Unique rates via WhatsApp, email, and SMS!',
      priceDropsBeforeTheyAre: 'Price drops before they are gone',
      flashSales: 'Flash sales',
      offersPickedForYou: 'Offers picked for you',
      agree: 'Agree',
      maybeLater: 'Maybe later',
      byClickingAgreeIConsent: 'By clicking Agree, I consent to receiving communications and acknowledge the',
      privacyPolicy: 'privacy policy',
      and: ', and',
      termsAndConditions: 'terms and conditions',
      youCanOptOutAnytime: 'You can opt-out anytime.'
    },
    signUp: {
      signInOrCreateAccount: 'Sign in or create account',
      code: 'Code',
      mobileNumber: 'Mobile number',
      continue: 'Continue',
      registerAsABusiness: 'Register as a Business',
      continueWithEmail: 'Continue with email',
      continueWithApple: 'Continue with Apple',
      continueWithGoogle: 'Continue with Google'
    },
    sMS: {
      enterVerificationCode: 'Enter Verification Code',
      enterThe6DigitCode: 'Enter the 6-digit code sent via:',
      sms: 'SMS',
      at: 'at',
      resendIn: 'Resend in',
      _29Seconds: '29 seconds',
      digit1: 'Verification code, digit 1',
      digit2: 'Verification code, digit 2',
      digit3: 'Verification code, digit 3',
      digit4: 'Verification code, digit 4',
      digit5: 'Verification code, digit 5',
      digit6: 'Verification code, digit 6'
    }
  },
  ar: {
    cssProbe: {
      addYourTextHere: 'أضف نصك هنا.',
      probe: 'probe'
    },
    home: {
      home: 'الرئيسية',
      startEditingThisPageIn: 'ابدأ تحرير هذه الصفحة في Studio.'
    },
    onboardingHero: {
      almosafer: 'المسافر',
      _941Am: '9:41 ص',
      goodNewsAFewHotels: 'أخبار سارة! انخفضت أسعار بعض الفنادق التي تهتم بها بنسبة 30%'
    },
    onboarding: {
      agree: 'موافق',
      and: '، و',
      byClickingAgreeIConsent: 'بالنقر على موافق، أوافق على تلقي الاتصالات وأقرّ بـ',
      completeYourSetupDonT: 'أكمل إعدادك. لا تفوّت:',
      flashSales: 'عروض خاطفة',
      maybeLater: 'ربما لاحقًا',
      offersPickedForYou: 'عروض مختارة لك',
      priceDropsBeforeTheyAre: 'انخفاضات الأسعار قبل نفادها',
      privacyPolicy: 'سياسة الخصوصية',
      termsAndConditions: 'الشروط والأحكام',
      uniqueRatesViaWhatsappEmail: 'أسعار حصرية عبر واتساب والبريد والرسائل النصية!',
      youCanOptOutAnytime: 'يمكنك إلغاء الاشتراك في أي وقت.'
    },
    sheetHeader: {
      back: 'رجوع',
      close: 'إغلاق'
    },
    signUp: {
      code: 'الرمز',
      continue: 'متابعة',
      continueWithApple: 'المتابعة عبر Apple',
      continueWithEmail: 'المتابعة بالبريد الإلكتروني',
      continueWithGoogle: 'المتابعة عبر Google',
      mobileNumber: 'رقم الجوال',
      registerAsABusiness: 'التسجيل كشركة',
      signInOrCreateAccount: 'سجّل الدخول أو أنشئ حسابًا'
    },
    sMS: {
      _29Seconds: '29 ثانية',
      at: 'على',
      enterThe6DigitCode: 'أدخل الرمز المكوّن من 6 أرقام المُرسل عبر:',
      enterVerificationCode: 'أدخل رمز التحقق',
      resendIn: 'إعادة الإرسال خلال',
      sms: 'رسالة نصية',
      digit1: 'رمز التحقق، الرقم 1',
      digit2: 'رمز التحقق، الرقم 2',
      digit3: 'رمز التحقق، الرقم 3',
      digit4: 'رمز التحقق، الرقم 4',
      digit5: 'رمز التحقق، الرقم 5',
      digit6: 'رمز التحقق، الرقم 6'
    }
  },
}

/** The locale codes this app declares. */
export type Locale = keyof typeof translations

/** The language used when nothing else has been chosen. */
export const defaultLocale: Locale = 'en'
